PETS = {}
METAS = {}
PROGRESSO = {}
quantMC = 1


def adicionar():
    nome = input("Nome do pet: ").capitalize()
    especie = input("Espécie: ").capitalize()
    raca = input("Raça: ").capitalize()
    data = input("Data: ")
    peso = input("Peso em kg: ")
    PETS[nome] = f"Nome: {nome} \nEspécie: {especie} \nRaça: {raca} \nData de nascimento: {data} \nPeso: {peso} kg \n"
def visualizar():
    for nome in PETS:
        print(PETS[nome])
    print("\n")
def editar():
    nome_antigo = input("Digite o nome do pet que você deseja editar: ").capitalize()
    if nome_antigo not in PETS:
         print("Pet não encontrado.")
         return
    novo_nome = input("Novo nome: ").capitalize()
    nova_especie = input("Espécie: ").capitalize()
    nova_raca = input("Raça: ").capitalize()
    nova_data = input("Data: ")
    novo_peso = input("Peso em kg: ")
    PETS.pop(nome_antigo)
    PETS[novo_nome] = f"Nome: {novo_nome} \nEspécie: {nova_especie} \nRaça: {nova_raca} \nData de nascimento: {nova_data} \nPeso: {novo_peso} kg \n"
def remover():
    nome_remover = input("Digite o nome do pet que você deseja excluir: ").capitalize()
    PETS.pop(nome_remover)
def ler_arquivo():
    arquivo = open("pets.txt", "r", encoding="utf-8")
    linhas = arquivo.read().split('\n')
    for linha in linhas:
        if linha == '':
            break
        nome, *_ = linha.split(",")
        PETS[nome] = linha
    arquivo.close()
def gravar_arquivo():
    arquivo = open("pets.txt", "w", encoding="utf-8")
    for chave in PETS:
        arquivo.writelines(PETS[chave] + '\n')
    arquivo.close()

def gravar_metas():
    file = open("meta.txt", "w", encoding="utf-8")
    for chave in METAS:
        file.writelines(METAS[chave] + 'n')
    for chave in PROGRESSO:
        file.writelines(PROGRESSO[chave] + 'n')
    file.close()



def meta():
    opc = 0
    global quantMC
    

    print("1 - add / 2 - upd")
    opc = int(input("Qual opcao? "))
    if opc == 1:
        escolha = input("\nPara qual pet você quer estabelecer uma meta? ")
        acao = input(f"\nQual a meta definida para o pet {escolha}? ")
        relacao_tempo = input("\nEssa meta será diária, semanal, mensal ou anual? (D / S / M / A): ").lower()
        if relacao_tempo == "d":
            frequencia = float(input("\nCom que frequência você quer realizá-la?  "))
            METAS[quantMC]=(f"{quantMC}ª META -> {escolha} -> {acao} {frequencia} vezes por dia")
        elif relacao_tempo == "s":
            tipo_semana = int(input("\nEscolha qual tipo será: 1 - por semana / 2 - a cada x semanas "))
            if tipo_semana == 1:
                frequencia = float(input("\nCom que frequência você quer realizá-la?  "))
                METAS[quantMC]=(f"{quantMC}ª META -> {escolha} -> {acao} {frequencia} vezes por semana")
            elif tipo_semana == 2:
                frequencia = float(input("\nCom que frequência você quer realizá-la?  "))
                METAS[quantMC]=(f"{quantMC}ª META -> {escolha} -> {acao} a cada {frequencia} semanas")
        elif relacao_tempo == "m":
            tipo_mes = int(input("\nEscolha qual tipo será: 1 - por mês / 2 - a cada x meses "))
            if tipo_mes == 1:
                frequencia = float(input("\nCom que frequência você quer realizá-la?  "))
                METAS[quantMC]=(f"{quantMC}ª META -> {escolha} -> {acao} {frequencia} vezes por mês")
            elif tipo_mes == 2:
                frequencia = float(input("\nCom que frequência você quer realizá-la?  "))
                METAS[quantMC]=(f"{quantMC}ª META -> {escolha} -> {acao} a cada {frequencia} meses ")
        elif relacao_tempo == "a":
            tipo_ano = int(input("\nEscolha qual tipo será: 1 - por ano / 2 - a cada x anos "))
            if tipo_ano == 1:
                frequencia = float(input("\nCom que frequência você quer realizá-la?  "))
                METAS[quantMC]=(f"{quantMC}ª META -> {escolha} -> {acao} {frequencia} vezes por ano")
            elif tipo_ano == 2: 
                frequencia = float(input("\nCom que frequência você quer realizá-la?  "))
                METAS[quantMC]=(f"{quantMC}ª META -> {escolha} -> {acao} a cada {frequencia} meses ")
                    
        PROGRESSO[quantMC] = 0

        print("\nMeta registrada com sucesso!")
        print(f"\n {METAS}")
        quantMC+=1
    elif opc == 2:
        if not METAS:
            print("\nNão há metas registradas.")
        else:
            total_feito = 0
            print("\nMetas: ")
            for i in METAS:
                print(f"{i}: {METAS[i]}")
            numupd = int(input("\nQual meta será atualizada? "))
            cumprido = float(input("\nQuantos % você ja cumpriu da meta? "))
            PROGRESSO[numupd] += cumprido
                    
            if PROGRESSO[numupd] >=100:
                print("\nParabéns! Você cumpriu a meta!")
                del METAS[numupd]
                del PROGRESSO[numupd]
            else:
                print(f"\nAinda faltam {100 - PROGRESSO[numupd]} % da meta")

    return METAS , PROGRESSO, quantMC
       
while True:
    print("-="*30)
    print("Bem-vindo ao CRUD")
    print("1- Adicionar Pet")
    print("2- Visualizar Pets Cadastrados")
    print("3- Editar Pet")
    print("4- Excluir Registros do Pet")
    print("5- Metas e atualizações")
    print("6- Sair")
    escolha=int(input("Opção: "))
    if escolha==1:
        adicionar()
        gravar_arquivo()
    elif escolha==2:
        visualizar()
    elif escolha==3:
        editar()
        gravar_arquivo()
    elif escolha==4:
        remover()
        gravar_arquivo()
    elif escolha ==5:
        meta()
    elif escolha==6:   
        break
    else:
         print("Opção Inválida! ")